﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace _5
{
    public partial class CreateShipment : Form
    {
        private SqlConnection connection;
        public CreateShipment()
        {
            InitializeComponent();
            string connectionString = "Data Source=DASHKOM\\SQLEXPRESS;Initial Catalog=second;Integrated Security=True";
            connection = new SqlConnection(connectionString);
            CBFill();
        }
        private Dictionary<string, int> orderDictionary = new Dictionary<string, int>();
        private Dictionary<string, int> productDictionary = new Dictionary<string, int>();
        private void CBFill()
        {
            try
            {
                connection.Open();
                string orderQuery = "SELECT Код FROM Заказы";
                SqlCommand orderCmd = new SqlCommand(orderQuery, connection);
                SqlDataReader orderReader = orderCmd.ExecuteReader();

                while (orderReader.Read())
                {
                    int orderCode = Convert.ToInt32(orderReader["Код"]);
                    string orderName = orderReader["Код"].ToString();
                    comboBox1.Items.Add(orderName);
                    orderDictionary.Add(orderName, orderCode);
                }
                orderReader.Close();

                string productQuery = "SELECT Код, Наименование FROM Товары";
                SqlCommand productCmd = new SqlCommand(productQuery, connection);
                SqlDataReader productReader = productCmd.ExecuteReader();

                while (productReader.Read())
                {
                    int productCode = Convert.ToInt32(productReader["Код"]);
                    string productName = productReader["Наименование"].ToString();
                    comboBox2.Items.Add(productName);
                    productDictionary.Add(productName, productCode);
                }
                productReader.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при заполнении ComboBox: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
        }


        private void SaveDate()
        {
            try
            {
                connection.Open();
                string orderId = comboBox1.SelectedItem.ToString();
                string date = maskedTextBox1.Text;
                string product = comboBox2.SelectedItem.ToString();
                string count = textBox1.Text;
                int orderCode = orderDictionary[orderId];
                int productCode = productDictionary[product];


                string insertQuery = "INSERT INTO Отгрузки (КодЗаказа, Дата, Товар, КоличествоТоваров) VALUES " +
                    "(@КодЗаказа, @Дата, @Товар, @КоличествоТоваров)";
                SqlCommand insertCmd = new SqlCommand(insertQuery, connection);
                insertCmd.Parameters.AddWithValue("@КодЗаказа", orderCode);
                insertCmd.Parameters.AddWithValue("@Дата", date);
                insertCmd.Parameters.AddWithValue("@Товар", productCode);
                insertCmd.Parameters.AddWithValue("@КоличествоТоваров", count);

                // Выполнение запроса на добавление данных
                insertCmd.ExecuteNonQuery();
                MessageBox.Show("Данные успешно добавлены!", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при сохранении данных: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SaveDate();
            Close();
        }
    }
}
