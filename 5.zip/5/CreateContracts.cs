﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace _5
{
    public partial class CreateContracts : Form
    {
        private SqlConnection connection;

        public CreateContracts()
        {
            InitializeComponent();
            string connectionString = "Data Source=DASHKOM\\SQLEXPRESS;Initial Catalog=second;Integrated Security=True";
            connection = new SqlConnection(connectionString);
            CBFill();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SaveDate();
            Close();
        }
        private Dictionary<string, int> customerDictionary = new Dictionary<string, int>();
        private void CBFill()
        {
            try
            {
                connection.Open();
                string query = "SELECT Код, Наименование FROM Заказчики";
                SqlCommand cmd = new SqlCommand(query, connection);
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    int код = Convert.ToInt32(reader["Код"]);
                    string наименование = reader["Наименование"].ToString();
                    comboBox1.Items.Add(наименование);
                    customerDictionary.Add(наименование, код);
                }
                reader.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при заполнении ComboBox: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
        }

        private void SaveDate()
        {
            try
            {
                connection.Open();
                string date = maskedTextBox1.Text;
                string наименование = comboBox1.SelectedItem.ToString();
                int customerCode = customerDictionary[наименование];

                string insertQuery = "INSERT INTO Договоры (ДатаЗаключения, Заказчик) VALUES (@ДатаЗаключения, @Заказчик)";
                SqlCommand insertCmd = new SqlCommand(insertQuery, connection);
                insertCmd.Parameters.AddWithValue("@ДатаЗаключения", date);
                insertCmd.Parameters.AddWithValue("@Заказчик", customerCode);

                // Выполнение запроса на добавление данных
                insertCmd.ExecuteNonQuery();
                MessageBox.Show("Данные успешно добавлены!", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при сохранении данных: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
        }
    }
}
