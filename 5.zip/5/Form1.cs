﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using lib;

namespace _5
{
    public partial class Form1 : Form
    {
        private Database db;
        public Form1()
        {
            InitializeComponent();
            this.Dock = DockStyle.Fill;
            string connectionString = "Data Source=DASHKOM\\SQLEXPRESS;Initial Catalog=second;Integrated Security=True";
            db = new Database(connectionString);
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            textBox2.UseSystemPasswordChar = true;
            pictureBox2.Visible = true;
            pictureBox1.Visible = false;
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            textBox2.UseSystemPasswordChar = false;
            pictureBox2.Visible = false;
            pictureBox1.Visible = true;
        }
        private DataRow AuthenticateUser(string login, string password)
        {
            string query = "SELECT * FROM [dbo].[Пользователи] WHERE Логин = @login AND Пароль = @password";

            using (SqlCommand command = new SqlCommand(query, db.GetConnection()))
            {
                command.Parameters.AddWithValue("@login", login);
                command.Parameters.AddWithValue("@password", password);

                using (SqlDataReader reader = command.ExecuteReader())
                {
                    if (reader.HasRows)
                    {
                        DataTable dataTable = new DataTable();
                        dataTable.Load(reader);
                        return dataTable.Rows[0];
                    }
                    else
                    {
                        return null;
                    }
                }
            }
        }

        private string captcha;

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string login = textBox1.Text;
                string password = textBox2.Text;
                DataRow user = AuthenticateUser(login, password);

                if (user != null)
                {
                    string name = user["ФИО"].ToString();
                    string role = user["Должность"].ToString();

                    MessageBox.Show($"Добро пожаловать, {role} {name}");

                    Menu menu = new Menu(role, name);
                    menu.Show();
                    this.Hide();
                    return;
                }
                else
                {
                    textBox1.Enabled = false;
                    textBox2.Enabled = false;
                    label4.Visible = true;
                    label4.ForeColor = Color.Red;
                    label4.Text = "Неверный логин или пароль. Введите капчу.";
                    textBox1.Text = "";
                    textBox2.Text = "";
                    pictureBox3.Visible = true;
                    GenerateCaptcha();
                    textBox3.Visible = true;
                    return;
                    
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при аутентификации: " + ex.Message);
            }
        }
        private void GenerateCaptcha()
        {
            captcha = GenerateRandomString(4);

            // Создание изображения для фона
            Bitmap bitmap = new Bitmap(pictureBox3.Width, pictureBox3.Height);
            using (Graphics graphics = Graphics.FromImage(bitmap))
            {
                // Наложение графического шума (случайные линии и круги)
                Random random = new Random();
                for (int i = 0; i < 20; i++)
                {
                    int x1 = random.Next(bitmap.Width);
                    int y1 = random.Next(bitmap.Height);
                    int x2 = random.Next(bitmap.Width);
                    int y2 = random.Next(bitmap.Height);
                    graphics.DrawLine(new Pen(Color.Black), x1, y1, x2, y2);
                    graphics.DrawEllipse(new Pen(Color.DarkBlue), x1, y1, 8, 8);
                }

                // Наложение случайных символов на изображение
                Font font = new Font("Arial", 24, FontStyle.Bold);
                for (int i = 0; i < captcha.Length; i++)
                {
                    Brush brush = new SolidBrush(Color.DarkGray);
                    PointF point = new PointF(i * 30 + 10, random.Next(5, 20));
                    graphics.DrawString(captcha[i].ToString(), font, brush, point);
                }
            }

            // Отображение изображения в PictureBox
            pictureBox3.Image = bitmap;
        }

        private string GenerateRandomString(int length)
        {
            string chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
            Random random = new Random();
            return new string(Enumerable.Repeat(chars, length)
              .Select(s => s[random.Next(s.Length)]).ToArray());
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            db.OpenConnection();
            textBox2.UseSystemPasswordChar = true;
            timer1.Interval = 10000;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            timer1.Stop(); 
            button1.Enabled = true;
            textBox1.Enabled = true;
            textBox2.Enabled = true;
            textBox3.Visible = false;
            label4.Visible = false;
            pictureBox3.Visible = false;
            textBox3.Text = "";
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            if (textBox3.Text.Length == 4)
            {
                if (textBox3.Text == captcha)
                {
                    textBox1.Enabled = true;
                    textBox2.Enabled = true;
                    textBox3.Visible = false;
                    label4.Visible = false;
                    pictureBox3.Visible = false;
                }
                else
                {
                    textBox1.Enabled = false;
                    textBox2.Enabled = false;
                    textBox3.Visible = false;
                    pictureBox3.Visible = false;
                    button1.Enabled = false;
                    label4.Text = "Вы заблокированы. Повторите попытку через 10 секунд.";
                    timer1.Start();
                }
            }
        }
    }
}
