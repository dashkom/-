﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using lib;
using System.Collections;

namespace _5
{
    public partial class Create : Form
    {
        private string tb;
        private Database db;
        private string columnName;
        public Create(string tb)
        {
            InitializeComponent();
            this.tb = tb;
            string connectionString = "Data Source=DASHKOM\\SQLEXPRESS;Initial Catalog=second;Integrated Security=True";
            db = new Database(connectionString);
            LoadColumnNames();
            label1.Text = tb;
        }
        private void LoadColumnNames()
        {
            DataTable schemaTable = GetSchemaTable(tb);
            
            int yPos = 120; // Начальная позиция по Y для контролов
            foreach (DataRow row in schemaTable.Rows)
            {
                string columnName = row["COLUMN_NAME"].ToString();

                Label label = new Label();
                label.Text = columnName;
                label.Location = new Point(220, yPos); // Устанавливаем позицию для label
                label.Size = new Size(180, 40);

                TextBox textBox = new TextBox();
                textBox.Name = columnName;
                textBox.Location = new Point(470, yPos); // Устанавливаем позицию для textBox
                textBox.Size = new Size(250, 40);

                this.Controls.Add(label); // Добавляем label на форму
                this.Controls.Add(textBox); // Добавляем textBox на форму

                yPos += 50; // Увеличиваем позицию по Y для следующего контрола
            }
        }

        private DataTable GetSchemaTable(string tableName)
        {
            // Здесь выполните запрос к базе данных для получения структуры таблицы
            // Пример запроса с использованием ADO.NET:
            string connectionString = "Data Source=DASHKOM\\SQLEXPRESS;Initial Catalog=second;Integrated Security=True";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = ($"SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = @TableName");
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@TableName", tableName);

                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);
                    return dataTable;
                }
            }
        }
        //////////////////////////////////////////////////////////////////////

        private void SaveData()
        {
            string connectionString = "Data Source=DASHKOM\\SQLEXPRESS;Initial Catalog=second;Integrated Security=True";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                // Проход по всем текстбоксам на форме и их значениям
                foreach (Control control in this.Controls)
                {
                    if (control is TextBox)
                    {
                        TextBox textBox = (TextBox)control;
                        columnName = textBox.Name; // Используйте переменную на уровне класса
                        string value = textBox.Text;

                        // Получить тип данных столбца из базы данных
                        string columnType = GetColumnType(columnName);

                        // Преобразование значения из текстбокса в соответствующий тип данных
                        object convertedValue = ConvertToType(value, columnType);

                        // Вставить значение в базу данных
                        string query = "INSERT INTO " + tb + " (" + columnName + ") VALUES (@Value)";
                        using (SqlCommand command = new SqlCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@Value", convertedValue);
                            command.ExecuteNonQuery();
                        }
                    }
                }
            }
        }

        private string GetColumnType(string columnName)
        {
            // Здесь выполните запрос к базе данных, чтобы получить тип данных для столбца
            // Пример:
            // SELECT DATA_TYPE FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = @TableName AND COLUMN_NAME = @ColumnName
            // Верните тип данных в виде строки (например, "nvarchar", "int", "datetime" и т.д.)
            string connectionString = "Data Source=DASHKOM\\SQLEXPRESS;Initial Catalog=second;Integrated Security=True";
            string columnType = "";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = "SELECT DATA_TYPE FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = @TableName AND COLUMN_NAME = @ColumnName";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@TableName", tb);
                    command.Parameters.AddWithValue("@ColumnName", columnName);

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            columnType = reader["DATA_TYPE"].ToString();
                        }
                        // Обработка случая, когда столбец с заданным именем не найден
                    }
                }
            }

            return columnType;
        }

        private object ConvertToType(string value, string columnType)
        {
            // Преобразование значения из текстбокса в соответствующий тип данных
            switch (columnType.ToLower())
            {
                case "int":
                    int intValue;
                    if (int.TryParse(value, out intValue))
                    {
                        return intValue;
                    }
                    // Обработка ошибки, если введенное значение невозможно преобразовать в int
                    break;
                case "date":
                    DateTime dateTimeValue;
                    if (DateTime.TryParse(value, out dateTimeValue))
                    {
                        return dateTimeValue;
                    }
                    // Обработка ошибки, если введенное значение невозможно преобразовать в DateTime
                    break;
                case "float":
                    float floatValue;
                    if (float.TryParse(value, out floatValue))
                    {
                        return floatValue;
                    }
                    break;
                // Добавьте другие типы данных по мере необходимости
                default:
                    return value;
            }

            // Обработка других типов данных и сценариев ошибок
            // Можете вернуть null или другое значение по умолчанию, если тип данных не определен
            return 1;    
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SaveData();
            this.Close();
        }
    }
}
