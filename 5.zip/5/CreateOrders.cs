﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _5
{
    public partial class CreateOrders : Form
    {
        private SqlConnection connection;
        public CreateOrders()
        {
            InitializeComponent();
            string connectionString = "Data Source=DASHKOM\\SQLEXPRESS;Initial Catalog=second;Integrated Security=True";
            connection = new SqlConnection(connectionString);
            CBFill();
        }
        private Dictionary<string, int> contractDictionary = new Dictionary<string, int>();
        private Dictionary<string, int> customerDictionary = new Dictionary<string, int>();
        private Dictionary<string, int> productDictionary = new Dictionary<string, int>();
        private void CBFill()
        {
            try
            {
                connection.Open();
                string contractQuery = "SELECT НомерДоговора FROM Договоры";
                SqlCommand contractCmd = new SqlCommand(contractQuery, connection);
                SqlDataReader contractReader = contractCmd.ExecuteReader();

                while (contractReader.Read())
                {
                    int contractCode = Convert.ToInt32(contractReader["НомерДоговора"]);
                    string contractName = contractReader["НомерДоговора"].ToString();
                    comboBox1.Items.Add(contractName);
                    contractDictionary.Add(contractName, contractCode);
                }
                contractReader.Close();

                string customerQuery = "SELECT Код, Наименование FROM Заказчики";
                SqlCommand customerCmd = new SqlCommand(customerQuery, connection);
                SqlDataReader customerReader = customerCmd.ExecuteReader();

                while (customerReader.Read())
                {
                    int customerCode = Convert.ToInt32(customerReader["Код"]);
                    string customerName = customerReader["Наименование"].ToString();
                    comboBox2.Items.Add(customerName);
                    customerDictionary.Add(customerName, customerCode);
                }
                customerReader.Close();

                string productQuery = "SELECT Код, Наименование FROM Товары";
                SqlCommand productCmd = new SqlCommand(productQuery, connection);
                SqlDataReader productReader = productCmd.ExecuteReader();

                while (productReader.Read())
                {
                    int productCode = Convert.ToInt32(productReader["Код"]);
                    string productName = productReader["Наименование"].ToString();
                    comboBox3.Items.Add(productName);
                    productDictionary.Add(productName, productCode);
                }
                productReader.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при заполнении ComboBox: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
        }


        private void SaveDate()
        {
            try
            {
                connection.Open();
                string numContr = comboBox1.SelectedItem.ToString();
                string cust = comboBox2.SelectedItem.ToString();
                string plan = textBox1.Text;
                string product = comboBox3.SelectedItem.ToString();
                int contractCode = contractDictionary[numContr];
                int customerCode = customerDictionary[cust];
                int productCode = productDictionary[product];


                string insertQuery = "INSERT INTO Заказы (НомерДоговора, Заказчик, ПлановаяДоставка, Товар) VALUES " +
                    "(@НомерДоговора, @Заказчик, @ПлановаяДоставка, @Товар)";
                SqlCommand insertCmd = new SqlCommand(insertQuery, connection);
                insertCmd.Parameters.AddWithValue("@НомерДоговора", contractCode);
                insertCmd.Parameters.AddWithValue("@Заказчик", customerCode);
                insertCmd.Parameters.AddWithValue("@ПлановаяДоставка", plan);
                insertCmd.Parameters.AddWithValue("@Товар", productCode);

                // Выполнение запроса на добавление данных
                insertCmd.ExecuteNonQuery();
                MessageBox.Show("Данные успешно добавлены!", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при сохранении данных: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SaveDate();
            Close();
        }
    }
}
