﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace _5
{
    public partial class CreateCustomers : Form
    {
        private SqlConnection connection;
        private int customerId;
        public CreateCustomers(int customerId)
        {
            InitializeComponent();
            string connectionString = "Data Source=DASHKOM\\SQLEXPRESS;Initial Catalog=second;Integrated Security=True";
            connection = new SqlConnection(connectionString);
            this.customerId = customerId;
            if (customerId > 0)
            {
                // Если идентификатор больше 0, это редактирование существующей записи, получите данные из базы данных
                LoadDataFromDatabase(customerId);
            }
        }
        private void LoadDataFromDatabase(int customerId)
        {
            try
            {
                connection.Open();
                string selectQuery = "SELECT Наименование, Адрес, Телефон FROM Заказчики WHERE Код = @Код";
                SqlCommand selectCmd = new SqlCommand(selectQuery, connection);
                selectCmd.Parameters.AddWithValue("@Код", customerId);

                SqlDataReader reader = selectCmd.ExecuteReader();
                if (reader.Read())
                {
                    // Установите значения в текстбоксы из базы данных
                    textBox1.Text = reader["Наименование"].ToString();
                    textBox2.Text = reader["Адрес"].ToString();
                    maskedTextBox1.Text = reader["Телефон"].ToString();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при загрузке данных: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
        }
        private void SaveDate()
        {
            try
            {
                connection.Open();
                string name = textBox1.Text;
                string address = textBox2.Text;
                string phone = maskedTextBox1.Text;

                if (customerId > 0) // Если идентификатор записи больше 0, это редактирование, иначе - создание новой записи
                {
                    string updateQuery = "UPDATE Заказчики SET Наименование = @Наименование, Адрес = @Адрес, Телефон = @Телефон WHERE Код = @Код";
                    SqlCommand updateCmd = new SqlCommand(updateQuery, connection);
                    updateCmd.Parameters.AddWithValue("@Наименование", name);
                    updateCmd.Parameters.AddWithValue("@Адрес", address);
                    updateCmd.Parameters.AddWithValue("@Телефон", phone);
                    updateCmd.Parameters.AddWithValue("@Код", customerId);

                    // Выполнение запроса на обновление данных
                    updateCmd.ExecuteNonQuery();
                }
                else // Если идентификатор записи меньше или равен 0, это создание новой записи
                {
                    string insertQuery = "INSERT INTO Заказчики (Наименование, Адрес, Телефон) VALUES (@Наименование, @Адрес, @Телефон)";
                    SqlCommand insertCmd = new SqlCommand(insertQuery, connection);
                    insertCmd.Parameters.AddWithValue("@Наименование", name);
                    insertCmd.Parameters.AddWithValue("@Адрес", address);
                    insertCmd.Parameters.AddWithValue("@Телефон", phone);

                    // Выполнение запроса на добавление данных
                    insertCmd.ExecuteNonQuery();
                }

                MessageBox.Show("Данные успешно сохранены!", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при сохранении данных: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
        }


        private void button1_Click(object sender, EventArgs e)
        {
            SaveDate();
            Close();
        }
    }
}
