﻿using lib;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Runtime.ConstrainedExecution;

namespace _5
{
    public partial class Menu : Form
    {
        private Database db;
        private DataTable currentDataTable;
        private string userRole;
        private string userName;
        private int recordId;
        public Menu(string role, string name)
        {
            InitializeComponent();
            userRole = role;
            userName = name;
            this.Dock = DockStyle.Fill;
            string connectionString = "Data Source=DASHKOM\\SQLEXPRESS;Initial Catalog=second;Integrated Security=True";
            db = new Database(connectionString);
        }
        private void Menu_Load(object sender, EventArgs e)
        {
            label2.Text = $"{userRole}, {userName}";
            if (userRole == "Работник склада")
            {
                button11.Enabled = false;
            }
            if (userRole == "Анализатор")
            {
                button11.Enabled = false;
            }
        }
        private void LoadOrdersData()
        {
            string connectionString = "Data Source=DASHKOM\\SQLEXPRESS;Initial Catalog=second;Integrated Security=True";

            string query = "SELECT Заказы.Код, Договоры.НомерДоговора, Заказчики.Наименование AS Наименование_Заказчика, " +
               "Заказы.ПлановаяДоставка, Товары.Наименование AS Наименование_Товара " +
               "FROM Заказы " +
               "INNER JOIN Договоры ON Заказы.НомерДоговора = Договоры.НомерДоговора " +
               "INNER JOIN Заказчики ON Заказы.Заказчик = Заказчики.Код " +
               "INNER JOIN Товары ON Заказы.Товар = Товары.Код";

            Parameter[] parameters = null;

            try
            {
                currentDataTable = Database.SelectQueryToDataGridView(connectionString, query, dataGridView1, parameters);
                
                dataGridView1.DataSource = currentDataTable;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                db.CloseConnection();
            }
        }
        private void LoadContractsData()
        {
            string connectionString = "Data Source=DASHKOM\\SQLEXPRESS;Initial Catalog=second;Integrated Security=True";

            string query = "SELECT Договоры.НомерДоговора, Договоры.ДатаЗаключения, Заказчики.Наименование AS Наименование_Заказчика " +
               "FROM Договоры " +
               "INNER JOIN Заказчики ON Договоры.Заказчик = Заказчики.Код";

            Parameter[] parameters = null;

            try
            {
                currentDataTable = Database.SelectQueryToDataGridView(connectionString, query, dataGridView1, parameters);
                dataGridView1.DataSource = currentDataTable;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                db.CloseConnection();
            }
        }
        private void LoadCustomersData()
        {
            string connectionString = "Data Source=DASHKOM\\SQLEXPRESS;Initial Catalog=second;Integrated Security=True";

            string query = "SELECT * FROM Заказчики";

            Parameter[] parameters = null;

            try
            {
                currentDataTable = Database.SelectQueryToDataGridView(connectionString, query, dataGridView1, parameters);
                dataGridView1.DataSource = currentDataTable;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                db.CloseConnection();
            }
        }
        private void LoadProductctsData()
        {
            string connectionString = "Data Source=DASHKOM\\SQLEXPRESS;Initial Catalog=second;Integrated Security=True";

            string query = "SELECT * FROM Товары";

            Parameter[] parameters = null;

            try
            {
                currentDataTable = Database.SelectQueryToDataGridView(connectionString, query, dataGridView1, parameters);
                dataGridView1.DataSource = currentDataTable;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                db.CloseConnection();
            }
        }
        private void LoadShipmentsData()
        {
            string connectionString = "Data Source=DASHKOM\\SQLEXPRESS;Initial Catalog=second;Integrated Security=True";

            string query = "SELECT Отгрузки.Код, Заказы.Код AS Код_Заказа, Отгрузки.Дата, " +
                   "Товары.Наименование AS Наименование_Товара, Отгрузки.КоличествоТоваров " +
                   "FROM Отгрузки " +
                   "INNER JOIN Заказы ON Отгрузки.КодЗаказа = Заказы.Код " +
                   "INNER JOIN Товары ON Отгрузки.Товар = Товары.Код";

            Parameter[] parameters = null;

            try
            {
                currentDataTable = Database.SelectQueryToDataGridView(connectionString, query, dataGridView1, parameters);
                dataGridView1.DataSource = currentDataTable;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                db.CloseConnection();
            }
        }
        private void LoadUsersData()
        {
            string connectionString = "Data Source=DASHKOM\\SQLEXPRESS;Initial Catalog=second;Integrated Security=True";

            string query = "SELECT * FROM Пользователи";

            Parameter[] parameters = null;

            try
            {
                currentDataTable = Database.SelectQueryToDataGridView(connectionString, query, dataGridView1, parameters);
                dataGridView1.DataSource = currentDataTable;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                db.CloseConnection();
            }
        }
        private void LoadUsersEnter()
        {
            string connectionString = "Data Source=DASHKOM\\SQLEXPRESS;Initial Catalog=second;Integrated Security=True";

            string query = "SELECT ЖурналВхода.Код, Пользователи.ФИО AS Пользователь, ЖурналВхода.Дата, " +
                   "ЖурналВхода.Время FROM ЖурналВхода " +
                   "INNER JOIN Пользователи ON ЖурналВхода.Пользователь = Пользователи.Код";

            Parameter[] parameters = null;

            try
            {
                currentDataTable = Database.SelectQueryToDataGridView(connectionString, query, dataGridView1, parameters);
                dataGridView1.DataSource = currentDataTable;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                db.CloseConnection();
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            label1.Text = "Заказы";
            LoadOrdersData();
            if (userRole == "Работник склада")
            {
                button10.Enabled = true;
                button9.Enabled = true;
                button8.Enabled = true;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            LoadContractsData();
            label1.Text = "Договоры";

            if (userRole == "Работник склада")
            {
                button10.Enabled = false;
                button9.Enabled = false;
                button8.Enabled = false;
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            label1.Text = "Заказчики";
            LoadCustomersData();
            if (userRole == "Работник склада")
            {
                button10.Enabled = false;
                button9.Enabled = false;
                button8.Enabled = false;
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            label1.Text = "Товары";
            LoadProductctsData();
            if (userRole == "Работник склада")
            {
                button10.Enabled = false;
                button9.Enabled = false;
                button8.Enabled = false;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            label1.Text = "Отгрузки";
            LoadShipmentsData();
            if (userRole == "Работник склада")
            {
                button10.Enabled = true;
                button9.Enabled = true;
                button8.Enabled = true;
            }
        }

        private void button11_Click(object sender, EventArgs e)
        {
            label1.Text = "Пользователи";
            LoadUsersData();
        }
        private void button7_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            //Create create = new Create(label1.Text);
            //create.ShowDialog();
            if (label1.Text == "Договоры")
            {
                CreateContracts createContracts = new CreateContracts();
                createContracts.ShowDialog();
            }
            else if (label1.Text == "Заказчики")
            {
                CreateCustomers createCustomers = new CreateCustomers(0);
                createCustomers.ShowDialog();
            }
            else if (label1.Text == "Заказы")
            {
                CreateOrders createOrders = new CreateOrders();
                createOrders.ShowDialog();
            }
            else if (label1.Text == "Отгрузки")
            {
                CreateShipment createShipment = new CreateShipment();
                createShipment.ShowDialog();
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            CreateCustomers createCustomers = new CreateCustomers(recordId);
            createCustomers.ShowDialog();
        }
        
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.ColumnIndex >= 0)
            {
                DataGridViewRow selectedRow = dataGridView1.Rows[e.RowIndex];
                int columnIndex = 0;
                recordId = Convert.ToInt32(selectedRow.Cells[columnIndex].Value);
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (recordId > 0)
            {
                DialogResult result = MessageBox.Show("Вы уверены, что хотите удалить эту запись?", "Подтверждение удаления", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                if (result == DialogResult.Yes)
                {
                    string connectionString = "Data Source=DASHKOM\\SQLEXPRESS;Initial Catalog=second;Integrated Security=True";
                    string tableName = label1.Text;

                    string deleteQuery = $"DELETE FROM {tableName} WHERE Код = @Код";

                    using (SqlConnection connection = new SqlConnection(connectionString))
                    using (SqlCommand deleteCommand = new SqlCommand(deleteQuery, connection))
                    {
                        deleteCommand.Parameters.AddWithValue("@Код", recordId);

                        try
                        {
                            connection.Open();
                            int rowsAffected = deleteCommand.ExecuteNonQuery();

                            if (rowsAffected > 0)
                            {
                                MessageBox.Show("Запись успешно удалена!", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                            else
                            {
                                MessageBox.Show("Запись не найдена.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Ошибка при удалении записи: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Выберите запись для удаления.", "Предупреждение", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            label1.Text = "История входа";
            LoadUsersEnter();
            if (userRole == "Работник склада")
            {
                button10.Enabled = false;
                button9.Enabled = false;
                button8.Enabled = false;
            }
        }
    }
    
}
